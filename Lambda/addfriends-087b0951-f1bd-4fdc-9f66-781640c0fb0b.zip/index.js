const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB({region: 'eu-west-2', apiVersion: '2012-08-10'});


exports.fn = (event, context, callback) => {
    
    var _id = Math.round((Math.random() * 36 ** 12)).toString(36)
    
    const params = {
        Item: {
            "Id" : {
              S : "dna_" + _id
            },
            "UserId": {
                S: event.receiver.id
            },
            "UserName": {
                S: event.receiver.name
            },
            "FriendId": {
                S: event.sender.id
            },
            "FriendName": {
                S: event.sender.name
            },
            "Status": {
                S: "Pending"
            },
            
        },
        TableName: "my-friends"
    };
    dynamodb.putItem(params, function(err, data) {
        if (err) {
            console.log(err);
            callback(err);
        } else {
            console.log(data);
            callback(null, getSuccessResponse("dna_" + _id, event));
        }
    });
};

var getSuccessResponse = function (id, event){
  console.log("Created friend request with with id: " + id)
  var response = {
    statusCode: 200,
    body: JSON.stringify({
      location: "friends" + id,
      sender: event.sender.name,
      status: "Pending"
      
    })
  };
 
  return response;
}