'use strict';

const aws = require('aws-sdk');

// It is recommended that we instantiate AWS clients outside the scope of the handler 
// to take advantage of connection re-use.
const docClient = new aws.DynamoDB.DocumentClient({region: 'eu-west-2', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    
    console.log("events id :: "+ event.id);
    console.log("events status :: "+ event.status);
    
    const params = {
        TableName: "my-friends",
        Key: {
            "Id": event.id
        },
        UpdateExpression: "set #MyVariable = :x",
        ExpressionAttributeNames: {
            "#MyVariable": "Status"
        },
        ExpressionAttributeValues: {
            ":x": event.status
        }
    };

    docClient.update(params, function(err, data) {
        if (err) 
        {
            console.log(err);
            callback(JSON.stringify({message : "Something gone wrong!"}))
        }
        else 
        {
            console.log(JSON.stringify({message : "Request has been " + event.status}));
            callback(null, JSON.stringify({message : "Request has been " + event.status}));
        }
    });
};