const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB({region: 'eu-west-2', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    const id = event.id;
    
    const params = {
        Key: {
            "Id": {
                S: id
            }
        },
        TableName: "my-friends"
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            console.log(err);
            callback(err);
        } else {
            console.log(data);
            callback(null, {sender: { id: +data.Item.FriendId.S, name: data.Item.FriendName.S}, receiver : { id: +data.Item.UserId.S, name : data.Item.UserName.S}, status: data.Item.Status.S });
        }
    });
   
};
