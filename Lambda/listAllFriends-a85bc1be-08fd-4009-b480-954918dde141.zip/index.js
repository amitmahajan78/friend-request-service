const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB({region: 'eu-west-2', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
      
      const authUser = event.authUser;
      console.log("Auth User :: " + authUser);
      const params = {
          TableName: 'my-friends'
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                console.log(err);
                callback(err);
            } else {
                console.log(data);
                
                var responseStr=[];
                
                data.Items.forEach(function(friends) {
                  
                  if (friends.UserName.S == authUser)
                  {
                        responseStr.push({requestId: friends.Id.S, sender: 
                                    { id: friends.FriendId.S, name: friends.FriendName.S}, 
                                    receiver : { id: friends.UserId.S, name : friends.UserName.S}, status: friends.Status.S })
                  }         
                });
                
                callback(null, responseStr);
            }
        });
};
